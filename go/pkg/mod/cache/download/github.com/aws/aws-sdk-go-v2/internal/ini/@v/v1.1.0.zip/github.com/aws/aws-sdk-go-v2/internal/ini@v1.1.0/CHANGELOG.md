# v1.1.0 (2021-07-01)

* **Feature**: Support for `:`, `=`, `[`, `]` being present in expression values.

# v1.0.1 (2021-06-25)

* **Dependency Update**: Updated to the latest SDK module versions

# v1.0.0 (2021-05-20)

* **Release**: The `github.com/aws/aws-sdk-go-v2/internal/ini` package is now a Go Module.
* **Dependency Update**: Updated to the latest SDK module versions

