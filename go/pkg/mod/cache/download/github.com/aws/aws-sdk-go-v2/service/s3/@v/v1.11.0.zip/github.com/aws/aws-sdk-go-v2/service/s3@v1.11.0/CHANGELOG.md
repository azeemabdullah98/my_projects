# v1.11.0 (2021-06-25)

* **Feature**: Updated `github.com/aws/smithy-go` to latest version
* **Dependency Update**: Updated to the latest SDK module versions

# v1.10.0 (2021-06-04)

* **Feature**: The handling of AccessPoint and Outpost ARNs have been updated.
* **Feature**: Updated service client to latest API model.
* **Dependency Update**: Updated to the latest SDK module versions

# v1.9.0 (2021-05-25)

* **Feature**: API client updated

# v1.8.0 (2021-05-20)

* **Feature**: API client updated
* **Dependency Update**: Updated to the latest SDK module versions

# v1.7.0 (2021-05-14)

* **Feature**: Constant has been added to modules to enable runtime version inspection for reporting.
* **Feature**: Updated to latest service API model.
* **Dependency Update**: Updated to the latest SDK module versions

